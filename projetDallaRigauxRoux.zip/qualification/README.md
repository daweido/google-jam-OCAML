1. *I/O Error S : 9pts* **OK**
2. *Cody's Jams S : 10pts* **OK**
3. *Captain Hammer : 11pts* **OK**

**TOAL : 30 pts**
