1. *NumberGame L : 25pts* **OK**
4. *Box Factory S : 12pts* **OK**

**TOTAL : 37pts**
