1. *Egg Drop S L : 40/80pts* **OK**
**TOTAL : 40/80pts**
