1. *Mountain Valley S : 13pts* **OK**
2. *Test Passing Probability S : 5pts* **PAS OK**
3. *Evaluation S : 12pts* **PAS OK**

**TOTAL : 13pts**
